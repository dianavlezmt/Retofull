package co.usa.ciclo32022.Reto3.Repository.crudrepository;

import co.usa.ciclo32022.Reto3.modelo.ReservationModel;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface ReservationCrudRepository extends CrudRepository<ReservationModel, Integer> {
    Optional<ReservationModel> getIdReservationRepository(Integer idReservation);
}
