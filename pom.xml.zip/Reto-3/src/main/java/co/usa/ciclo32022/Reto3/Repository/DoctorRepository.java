package co.usa.ciclo32022.Reto3.Repository;

import co.usa.ciclo32022.Reto3.Repository.crudrepository.DoctorCrudRepository;
import co.usa.ciclo32022.Reto3.modelo.DoctorModel;
import com.sun.istack.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.Id;
import java.util.List;
import java.util.Optional;

@Repository
public class DoctorRepository {

    @Autowired
    private DoctorCrudRepository doctorCrudRepository;

    public List<DoctorModel> getAllDoctors() {
        return (List<DoctorModel>) doctorCrudRepository.findAll();
    }

    public Optional<DoctorModel> getDoctor(Integer id) {
        return doctorCrudRepository.findById(id);
    }

    public DoctorModel saveDoctor(DoctorModel doctorModel) {

        return doctorCrudRepository.save(doctorModel);
    }

    public boolean deleteDoctor(Integer id) {
        doctorCrudRepository.deleteById(id);
        return true;
    }

    public DoctorModel updateDoctor(DoctorModel doctorModel) {
        if (doctorModel.getId() != null) {
            Optional<DoctorModel> doctor = doctorCrudRepository.findById(doctorModel.getId());
            if (!doctor.isEmpty()) {
                if (doctorModel.getName() != null) {
                    doctor.get().setName(doctorModel.getName());
                }
                if (doctorModel.getDepartment() != null) {
                    doctor.get().setDepartment(doctorModel.getName());
                }
                if (doctorModel.getYear() != null) {
                    doctor.get().setYear(doctorModel.getYear());
                }
                if (doctorModel.getDescription() != null) {
                    doctor.get().setDescription(doctorModel.getDescription());
                }
                if (doctorModel.getSpecialty() != null) {
                    doctor.get().setSpecialty(doctorModel.getSpecialty());
                }
                if (doctorModel.getMessages() != null) {
                    doctor.get().setMessages(doctorModel.getMessages());
                }
                if (doctorModel.getReservations() != null) {
                    doctor.get().setReservations(doctorModel.getReservations());
                }
                doctorCrudRepository.save(doctor.get());
                return doctor.get();
            } else {
                return doctorModel;
            }
        } else {
            return doctorModel;

        }
    }

}


