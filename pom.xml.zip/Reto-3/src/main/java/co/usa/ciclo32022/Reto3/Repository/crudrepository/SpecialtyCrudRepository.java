package co.usa.ciclo32022.Reto3.Repository.crudrepository;

import co.usa.ciclo32022.Reto3.modelo.SpecialtyModel;
import org.springframework.data.repository.CrudRepository;

public interface SpecialtyCrudRepository extends CrudRepository<SpecialtyModel, Integer> {
}
