package co.usa.ciclo32022.Reto3.Repository;


import co.usa.ciclo32022.Reto3.Repository.crudrepository.ClientCrudRepository;
import co.usa.ciclo32022.Reto3.modelo.ClientModel;
import com.sun.istack.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;


@Repository
public class ClientRepository {

    @Autowired
    private ClientCrudRepository clientCrudRepository;

    public List<ClientModel> getAllClients() {
        return (List<ClientModel>) clientCrudRepository.findAll();
    }

    public Optional<ClientModel> getClient(Integer idClient) {
        return clientCrudRepository.findById(idClient);
    }

    public ClientModel saveClient(ClientModel clientModel) {
        return clientCrudRepository.save(clientModel);
    }

    public boolean deleteClient(Integer idClient) {
        clientCrudRepository.deleteById(idClient);
        return true;
    }

}

    public ClientModel updateClient(ClientModel clientModel) {
        if (clientModel.getIdClient() != null) {
            Optional<ClientModel> e = clientCrudRepository.getIdClientCrudRepository(clientModel.getIdClient());
            if (e.isEmpty()) {
                if (clientModel.getName() != null) {
                    e.get().setName(clientModel.getName());
                }
                if (clientModel.getEmail() != null) {
                    e.get().setEmail(clientModel.getEmail());
                }
                if (clientModel.getAge() != null) {
                    e.get().setAge(clientModel.getAge());
                }
                if (clientModel.getPassword() != null) {
                    e.get().setPassword(clientModel.getPassword());
                }
                if (clientModel.getMessages() != null) {
                    e.get().setMessages(clientModel.getMessages());
                }
                if (clientModel.getReservations() != null) {
                    e.get().setReservations(clientModel.getReservations());
                }
                clientCrudRepository.saveClient(e.get());
                return e.get();
            } else {
                return clientModel;
            }
        } else {
            return clientModel;
        }
    }
}








